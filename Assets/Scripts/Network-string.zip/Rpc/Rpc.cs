using HarmonyLib;
using Mirror;
using MonoMod.Utils;
using SP.Tools;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;
using System;
using UnityEngine;
using System.Linq;
using System.Reflection.Emit;
using Mono.Cecil.Cil;
using System.ComponentModel;
using GameCore.Converters;
using Sirenix.Utilities;
using Newtonsoft.Json;

namespace GameCore
{
    //TODO: 性能优化
    //TODO: 自动写入Enum, 支持 sbyte, byte, short, ushort, int, uint, long, ulong
    //TODO: 完全支持实例方法
    public static class Rpc
    {
        public static Func<string, NetworkConnection, string[], Entity, bool> Remote;
        public static Action<string, NetworkConnection, string[], Entity> LocalMethod;



        static bool GetNetCallType(MethodInfo mtd, string mtdPath, Type voidType, Type connType, out RpcType type)
        {
            RpcAttribute att = null;
            type = RpcType.ServerRpc;

            if (AttributeGetter.TryGetAttribute<ServerRpcAttribute>(mtd, out var attTemp1))
            {
                type = RpcType.ServerRpc;
                att = attTemp1;
            }
            else if (AttributeGetter.TryGetAttribute<ClientRpcAttribute>(mtd, out var attTemp2))
            {
                type = RpcType.ClientRpc;
                att = attTemp2;
            }
            else if (AttributeGetter.TryGetAttribute<ConnectionRpc>(mtd, out var attTemp3))
            {
                type = RpcType.ConnectionRpc;
                att = attTemp3;
            }

            if (att == null)
            {
                return false;
            }



            if (mtd.ReturnType != voidType)
            {
                Debug.LogError($"{mtdPath} 使用了 {nameof(RpcAttribute)} 特性, 必须无返回值");
                return false;
            }

            var parameters = mtd.GetParameters();
            if (parameters.Length == 0 || parameters[^1].ParameterType != connType)
            {
                Debug.LogError($"{mtdPath} 使用了 {nameof(RpcAttribute)} 特性, 最后一个参数必须为 NetworkConnection");
                return false;
            }

            return true;
        }





        /* -------------------------------------------------------------------------- */
        /*                                   内部反射方法                                   */
        /* -------------------------------------------------------------------------- */
        public static bool _RemoteCall(NMRpc temp, ref NetworkConnection caller, string[] parameters, Entity instance)
        {
            temp.parameters = parameters;
            temp.instance = instance ? instance.netId : uint.MaxValue;

            //以下 Send 的回调绑定在 ManagerNetwork 中
            switch (temp.callType)
            {
                case RpcType.ServerRpc:
                    {
                        //如果是服务器就直接调用
                        if (Server.isServer)
                            LocalCall(temp.methodPath, caller ?? Server.localConnection, temp.parameters, temp.instance);
                        //如果是客户端就发给服务器
                        else
                            Client.Send(temp);

                        break;
                    }

                case RpcType.ClientRpc:
                    {
                        //如果是服务器就直接发给所有客户端
                        if (Server.isServer)
                            Server.Send(temp);
                        //如果是客户端就发给服务器, 让服务器发给所有客户端
                        else
                            Client.Send(temp);
                        break;
                    }

                case RpcType.ConnectionRpc:
                    {
                        /* //* 这通常不会触发报错, 在遇到问题时可以取消注释, 以便调试
                        if (caller == null)
                        {
                            Debug.LogError("调用 ConnectionRpc 时 conn 不能为空, 必须提供参数!");
                            return;
                        }

                        if (!Server.isServer)
                        {
                            Debug.LogError($"{nameof(NC_Type)}.{nameof(NC_Type.ConnectionRpc)} 方法只能在服务器被调用");
                            return;
                        }
                        */

                        //向发送者发送回去
                        caller.Send(temp);
                        break;
                    }
            }

            return false;
        }

        public static bool _StaticWrite0(NetworkConnection caller, MethodBase __originalMethod)
        {
            return Remote($"{__originalMethod.DeclaringType.FullName}.{__originalMethod.Name}", caller, null, null);
        }

        public static bool _StaticWrite1(NetworkConnection caller, object[] __args, MethodBase __originalMethod)
        {
            var parameters = __originalMethod.GetParameters();

            var values = new string[]
            {
                JsonTools.ToJson(__args[0])
            };

            return Remote($"{__originalMethod.DeclaringType.FullName}.{__originalMethod.Name}", caller, values, null);
        }

        public static bool _StaticWrite2(NetworkConnection caller, object[] __args, MethodBase __originalMethod)
        {
            var parameters = __originalMethod.GetParameters();

            var values = new string[]
            {
                JsonTools.ToJson(__args[0]),
                JsonTools.ToJson(__args[1])
            };

            return Remote($"{__originalMethod.DeclaringType.FullName}.{__originalMethod.Name}", caller, values, null);
        }

        public static bool _StaticWrite3(NetworkConnection caller, object[] __args, MethodBase __originalMethod)
        {
            var parameters = __originalMethod.GetParameters();

            var values = new string[]
            {
                JsonTools.ToJson(__args[0]),
                JsonTools.ToJson(__args[1]),
                JsonTools.ToJson(__args[2])
            };

            return Remote($"{__originalMethod.DeclaringType.FullName}.{__originalMethod.Name}", caller, values, null);
        }

        public static bool _StaticWrite4(NetworkConnection caller, object[] __args, MethodBase __originalMethod)
        {
            var parameters = __originalMethod.GetParameters();

            var values = new string[]
            {
                JsonTools.ToJson(__args[0]),
                JsonTools.ToJson(__args[1]),
                JsonTools.ToJson(__args[2]),
                JsonTools.ToJson(__args[3])
            };

            return Remote($"{__originalMethod.DeclaringType.FullName}.{__originalMethod.Name}", caller, values, null);
        }

        public static bool _StaticWrite5(NetworkConnection caller, object[] __args, MethodBase __originalMethod)
        {
            var parameters = __originalMethod.GetParameters();

            var values = new string[]
            {
                JsonTools.ToJson(__args[0]),
                JsonTools.ToJson(__args[1]),
                JsonTools.ToJson(__args[2]),
                JsonTools.ToJson(__args[3]),
                JsonTools.ToJson(__args[4])
            };

            return Remote($"{__originalMethod.DeclaringType.FullName}.{__originalMethod.Name}", caller, values, null);
        }

        public static bool _InstanceWrite0(NetworkConnection caller, Entity __instance, MethodBase __originalMethod)
        {
            return Remote($"{__originalMethod.DeclaringType.FullName}.{__originalMethod.Name}", caller, null, __instance);
        }

        public static bool _InstanceWrite1(NetworkConnection caller, object[] __args, Entity __instance, MethodBase __originalMethod)
        {
            var parameters = __originalMethod.GetParameters();

            var values = new string[]
            {
                JsonTools.ToJson(Convert.ChangeType(__args[0], parameters[0].ParameterType))
            };

            return Remote($"{__originalMethod.DeclaringType.FullName}.{__originalMethod.Name}", caller, values, __instance);
        }

        public static bool _InstanceWrite2(NetworkConnection caller, object[] __args, Entity __instance, MethodBase __originalMethod)
        {
            var parameters = __originalMethod.GetParameters();

            var values = new string[]
            {
                JsonTools.ToJson(Convert.ChangeType(__args[0], parameters[0].ParameterType)),
                JsonTools.ToJson(Convert.ChangeType(__args[1], parameters[1].ParameterType))
            };

            return Remote($"{__originalMethod.DeclaringType.FullName}.{__originalMethod.Name}", caller, values, __instance);
        }

        public static bool _InstanceWrite3(NetworkConnection caller, object[] __args, Entity __instance, MethodBase __originalMethod)
        {
            var parameters = __originalMethod.GetParameters();

            var values = new string[]
            {
                JsonTools.ToJson(Convert.ChangeType(__args[0], parameters[0].ParameterType)),
                JsonTools.ToJson(Convert.ChangeType(__args[1], parameters[1].ParameterType)),
                JsonTools.ToJson(Convert.ChangeType(__args[2], parameters[2].ParameterType))
            };

            return Remote($"{__originalMethod.DeclaringType.FullName}.{__originalMethod.Name}", caller, values, __instance);
        }

        public static bool _InstanceWrite4(NetworkConnection caller, object[] __args, Entity __instance, MethodBase __originalMethod)
        {
            var parameters = __originalMethod.GetParameters();

            var values = new string[]
            {
                JsonTools.ToJson(Convert.ChangeType(__args[0], parameters[0].ParameterType)),
                JsonTools.ToJson(Convert.ChangeType(__args[1], parameters[1].ParameterType)),
                JsonTools.ToJson(Convert.ChangeType(__args[2], parameters[2].ParameterType)),
                JsonTools.ToJson(Convert.ChangeType(__args[3], parameters[3].ParameterType))
            };

            return Remote($"{__originalMethod.DeclaringType.FullName}.{__originalMethod.Name}", caller, values, __instance);
        }

        public static bool _InstanceWrite5(NetworkConnection caller, object[] __args, Entity __instance, MethodBase __originalMethod)
        {
            var parameters = __originalMethod.GetParameters();

            var values = new string[]
            {
                JsonTools.ToJson(Convert.ChangeType(__args[0], parameters[0].ParameterType)),
                JsonTools.ToJson(Convert.ChangeType(__args[1], parameters[1].ParameterType)),
                JsonTools.ToJson(Convert.ChangeType(__args[2], parameters[2].ParameterType)),
                JsonTools.ToJson(Convert.ChangeType(__args[3], parameters[3].ParameterType)),
                JsonTools.ToJson(Convert.ChangeType(__args[4], parameters[4].ParameterType)),
            };

            return Remote($"{__originalMethod.DeclaringType.FullName}.{__originalMethod.Name}", caller, values, __instance);
        }












        //? 最多支持五个参数 (不包含NetworkConnection)
        public static object _Read0(Type[] parameterTypes, string[] parameters)
        {
            return JsonTools.LoadJsonByString(parameters[0], parameterTypes[0]);
        }

        public static object _Read1(Type[] parameterTypes, string[] parameters)
        {
            return JsonTools.LoadJsonByString(parameters[1], parameterTypes[1]);
        }

        public static object _Read2(Type[] parameterTypes, string[] parameters)
        {
            return JsonTools.LoadJsonByString(parameters[2], parameterTypes[2]);
        }

        public static object _Read3(Type[] parameterTypes, string[] parameters)
        {
            return JsonTools.LoadJsonByString(parameters[3], parameterTypes[3]);
        }

        public static object _Read4(Type[] parameterTypes, string[] parameters)
        {
            return JsonTools.LoadJsonByString(parameters[4], parameterTypes[4]);
        }









        internal static MethodInfo CopyMethod(MethodBase mtd)
        {
            using var dynamicMethod = new DynamicMethodDefinition(mtd);
            MethodInfo after = dynamicMethod.Generate();

            return after;
        }




        public static void Init()
        {
            /* -------------------------------------------------------------------------- */
            /*                              //Step 1: 定义反射参数
            /* -------------------------------------------------------------------------- */
            //Substep1: 获取类型和标记
            Type voidType = typeof(void);
            Type connType = typeof(NetworkConnection);
            BindingFlags flags = ReflectionTools.BindingFlags_All;

            //Substep2: 获取定义的方法
            var _RemoteCall = typeof(Rpc).GetMethod($"{nameof(Rpc._RemoteCall)}");

            var _StaticWrite0 = typeof(Rpc).GetMethod($"{nameof(Rpc._StaticWrite0)}");
            var _StaticWrite1 = typeof(Rpc).GetMethod($"{nameof(Rpc._StaticWrite1)}");
            var _StaticWrite2 = typeof(Rpc).GetMethod($"{nameof(Rpc._StaticWrite2)}");
            var _StaticWrite3 = typeof(Rpc).GetMethod($"{nameof(Rpc._StaticWrite3)}");
            var _StaticWrite4 = typeof(Rpc).GetMethod($"{nameof(Rpc._StaticWrite4)}");
            var _StaticWrite5 = typeof(Rpc).GetMethod($"{nameof(Rpc._StaticWrite5)}");

            var _InstanceWrite0 = typeof(Rpc).GetMethod($"{nameof(Rpc._InstanceWrite0)}");
            var _InstanceWrite1 = typeof(Rpc).GetMethod($"{nameof(Rpc._InstanceWrite1)}");
            var _InstanceWrite2 = typeof(Rpc).GetMethod($"{nameof(Rpc._InstanceWrite2)}");
            var _InstanceWrite3 = typeof(Rpc).GetMethod($"{nameof(Rpc._InstanceWrite3)}");
            var _InstanceWrite4 = typeof(Rpc).GetMethod($"{nameof(Rpc._InstanceWrite4)}");
            var _InstanceWrite5 = typeof(Rpc).GetMethod($"{nameof(Rpc._InstanceWrite5)}");

            var _Read0 = typeof(Rpc).GetMethod($"{nameof(Rpc._Read0)}");
            var _Read1 = typeof(Rpc).GetMethod($"{nameof(Rpc._Read1)}");
            var _Read2 = typeof(Rpc).GetMethod($"{nameof(Rpc._Read2)}");
            var _Read3 = typeof(Rpc).GetMethod($"{nameof(Rpc._Read3)}");
            var _Read4 = typeof(Rpc).GetMethod($"{nameof(Rpc._Read4)}");


            /* -------------------------------------------------------------------------- */
            /*                         //Step 2: 定义 Expression 参数
            /* -------------------------------------------------------------------------- */
            //Substep 1: 定义传入方法的参数
            ParameterExpression remoteParam_id = Expression.Parameter(typeof(string), "id");
            ParameterExpression remoteParam_caller = Expression.Parameter(typeof(NetworkConnection), "caller");
            ParameterExpression remoteParam_writer = Expression.Parameter(typeof(string[]), "parameters");
            ParameterExpression remoteParam_instance = Expression.Parameter(typeof(Entity), "instance");

            ParameterExpression localParam_id = Expression.Parameter(typeof(string), "id");
            ParameterExpression localParam_caller = Expression.Parameter(typeof(NetworkConnection), "caller");
            ParameterExpression localParam_parameters = Expression.Parameter(typeof(string[]), "parameters");
            ParameterExpression localParam_instance = Expression.Parameter(typeof(Entity), "instance");

            //Substep 2: 定义 Switch Cases
            List<SwitchCase> remoteCases = new();
            List<SwitchCase> localCases = new();

            ModFactory.assemblies.Foreach(ass => {
                ass.GetTypes().ForEach(type =>
                {
                    if (AttributeGetter.TryGetAttribute<JsonConvertersClassAttribute>(type, out _))
                    {
                        type.GetNestedTypes(flags).ForEach(nested =>
                        {
                            if (nested.IsSubclassOf(typeof(JsonConverter)))
                            {
                                Debug.Log(nested.FullName);
                                JsonTools.converters.Add((JsonConverter)Activator.CreateInstance(nested));
                            }
                        });
                    }
                });
            });


            /* -------------------------------------------------------------------------- */
            /*                              //Step 6: 更改带有 RpcBinder 的方法的内容
            /* -------------------------------------------------------------------------- */

            //获取所有可用方法
            ModFactory.EachUserMethod((ass, type, mtd) =>
            {
                string mtdPath = $"{type.FullName}.{mtd.Name}";

                //获取呼叫类型
                if (GetNetCallType(mtd, mtdPath, voidType, connType, out RpcType callType))
                {
                    /* ---------------------------------- 生成常量 ---------------------------------- */
                    var mtdPathConst = Expression.Constant(mtdPath);
                    var mtdInfo = Expression.Constant(new NMRpc(mtdPath, callType));

                    /* ---------------------------------- 获取参数 ---------------------------------- */
                    var totalParameters = mtd.GetParameters();   //分为真正的参数和 NetworkConnection
                    List<Type> trueParameters = new();
                    for (int i = 0; i < totalParameters.Length - 1; i++)
                    {
                        var pa = totalParameters[i];
                        trueParameters.Add(pa.ParameterType);
                    }
                    var parameterListConst = Expression.Constant(trueParameters.ToArray());

                    /* ---------------------------------- 编辑方法 ---------------------------------- */
                    try
                    {
                        MethodInfo mtdCopy = CopyMethod(mtd);
                        Harmony harmony = new($"Rpc.harmony.{mtdPath}");

                        void PatchMethod(MethodInfo patch)
                        {
                            harmony.Patch(mtd, new HarmonyMethod(patch));
                        }

                        UnaryExpression LocalCaseGeneration(int index)
                        {
                            //*== return (T)JsonTools.LoadJsonByString(localParam_parameters[index], trueParameters[index])
                            return Expression.Convert(
                                        Expression.Call(
                                            typeof(JsonTools).GetMethod("LoadJsonByString", new Type[] { typeof(string), typeof(Type) }),
                                            localParam_parameters.ArrayItem(index),
                                            Expression.Constant(trueParameters[index], typeof(Type))
                                        ),
                                        trueParameters[index]
                                    );
                        }

                        if (mtd.IsStatic)
                        {
                            PatchMethod(trueParameters.Count switch
                            {
                                0 => _StaticWrite0,
                                1 => _StaticWrite1,
                                2 => _StaticWrite2,
                                3 => _StaticWrite3,
                                4 => _StaticWrite4,
                                5 => _StaticWrite5,
                                _ => null
                            });

                            /* --------------------------------- 绑定 Case -------------------------------- */
                            //? 以下为重难点
                            //? == 表示等效于
                            //? 认真看其实很好理解


                            //*== case mtdPath:
                            //*==   _RemoteCall(mtdInfo, caller, writer);
                            //*==   break;
                            remoteCases.Add(Expression.SwitchCase(Expression.Call(null, _RemoteCall, mtdInfo, remoteParam_caller, remoteParam_writer, Expression.Constant(null, typeof(Entity))), mtdPathConst));

                            switch (trueParameters.Count)
                            {
                                case 0:
                                    localCases.Add(Expression.SwitchCase(
                                        Expression.Call(
                                            mtdCopy,
                                            localParam_caller
                                        ), mtdPathConst));
                                    break;

                                case 1:
                                    localCases.Add(Expression.SwitchCase(
                                        Expression.Call(
                                            mtdCopy,
                                            LocalCaseGeneration(0),
                                            localParam_caller
                                        ), mtdPathConst));
                                    break;

                                case 2:
                                    localCases.Add(Expression.SwitchCase(
                                        Expression.Call(
                                            mtdCopy,
                                            LocalCaseGeneration(0),
                                            LocalCaseGeneration(1),
                                            localParam_caller
                                        ), mtdPathConst));
                                    break;

                                case 3:
                                    localCases.Add(Expression.SwitchCase(
                                        Expression.Call(
                                            mtdCopy,
                                            LocalCaseGeneration(0),
                                            LocalCaseGeneration(1),
                                            LocalCaseGeneration(2),
                                            localParam_caller
                                        ), mtdPathConst));
                                    break;

                                case 4:
                                    localCases.Add(Expression.SwitchCase(
                                        Expression.Call(
                                            mtdCopy,
                                            LocalCaseGeneration(0),
                                            LocalCaseGeneration(1),
                                            LocalCaseGeneration(2),
                                            LocalCaseGeneration(3),
                                            localParam_caller
                                        ), mtdPathConst));
                                    break;

                                case 5:
                                    localCases.Add(Expression.SwitchCase(
                                        Expression.Call(
                                            mtdCopy,
                                            LocalCaseGeneration(0),
                                            LocalCaseGeneration(1),
                                            LocalCaseGeneration(2),
                                            LocalCaseGeneration(3),
                                            LocalCaseGeneration(4),
                                            localParam_caller
                                        ), mtdPathConst));
                                    break;

                                default:
                                    Debug.LogError($"方法 {mtdPath} 包含不支持的参数数量");
                                    break;
                            }
                        }
                        else
                        {
                            PatchMethod(trueParameters.Count switch
                            {
                                0 => _InstanceWrite0,
                                1 => _InstanceWrite1,
                                2 => _InstanceWrite2,
                                3 => _InstanceWrite3,
                                4 => _InstanceWrite4,
                                5 => _InstanceWrite5,
                                _ => null
                            });

                            /* --------------------------------- 绑定 Case -------------------------------- */
                            //? 以下为重难点
                            //? == 表示等效于
                            //? 认真看其实很好理解


                            //*== case mtdPath:
                            //*==   _RemoteCall(mtdInfo, caller, writer);
                            //*==   break;
                            remoteCases.Add(Expression.SwitchCase(Expression.Call(null, _RemoteCall, mtdInfo, remoteParam_caller, remoteParam_writer, remoteParam_instance), mtdPathConst));

                            switch (trueParameters.Count)
                            {
                                case 0:
                                    localCases.Add(Expression.SwitchCase(
                                        Expression.Call(
                                            mtdCopy,
                                            Expression.Convert(localParam_instance, mtdCopy.GetParameters()[0].ParameterType),
                                            localParam_caller
                                        ), mtdPathConst));
                                    break;

                                case 1:
                                    localCases.Add(Expression.SwitchCase(
                                        Expression.Call(
                                            mtdCopy,
                                            Expression.Convert(localParam_instance, mtdCopy.GetParameters()[0].ParameterType),
                                            LocalCaseGeneration(0),
                                            localParam_caller
                                        ), mtdPathConst));
                                    break;

                                case 2:
                                    localCases.Add(Expression.SwitchCase(
                                        Expression.Call(
                                            mtdCopy,
                                            Expression.Convert(localParam_instance, mtdCopy.GetParameters()[0].ParameterType),
                                            LocalCaseGeneration(0),
                                            LocalCaseGeneration(1),
                                            localParam_caller
                                        ), mtdPathConst));
                                    break;

                                case 3:
                                    localCases.Add(Expression.SwitchCase(
                                        Expression.Call(
                                            mtdCopy,
                                            Expression.Convert(localParam_instance, mtdCopy.GetParameters()[0].ParameterType),
                                            LocalCaseGeneration(0),
                                            LocalCaseGeneration(1),
                                            LocalCaseGeneration(2),
                                            localParam_caller
                                        ), mtdPathConst));
                                    break;

                                case 4:
                                    localCases.Add(Expression.SwitchCase(
                                        Expression.Call(
                                            mtdCopy,
                                            Expression.Convert(localParam_instance, mtdCopy.GetParameters()[0].ParameterType),
                                            LocalCaseGeneration(0),
                                            LocalCaseGeneration(1),
                                            LocalCaseGeneration(2),
                                            LocalCaseGeneration(3),
                                            localParam_caller
                                        ), mtdPathConst));
                                    break;

                                case 5:
                                    localCases.Add(Expression.SwitchCase(
                                        Expression.Call(
                                            mtdCopy,
                                            Expression.Convert(localParam_instance, mtdCopy.GetParameters()[0].ParameterType),
                                            LocalCaseGeneration(0),
                                            LocalCaseGeneration(1),
                                            LocalCaseGeneration(2),
                                            LocalCaseGeneration(3),
                                            LocalCaseGeneration(4),
                                            localParam_caller
                                        ), mtdPathConst));
                                    break;

                                default:
                                    Debug.LogError($"方法 {mtdPath} 包含不支持的参数数量");
                                    break;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new($"尝试编辑方法 {mtdPath} 时发生了错误:\n{ex}");
                    }
                }
            });






            /* -------------------------------------------------------------------------- */
            /*                  //Step 7: 编译 Remote & LocalMethod 用于直接调用
            /* -------------------------------------------------------------------------- */

            //SubStep 1: 定义未找到方法时的报错
            //* Debug.LogError($"远程调用方法失败: 未找到方法 {path}");
            //*     return true;
            var remoteNotFoundError = Expression.Block(
                                                        Expression.Call(
                                                            null,
                                                            typeof(Debug).GetMethod("LogError", new Type[] { typeof(object) }),
                                                            Expression.Call(typeof(string).GetMethod("Concat", new Type[] { typeof(string), typeof(string) }),
                                                                Expression.Constant("远程调用方法失败: 未找到方法 ", typeof(string)),
                                                                remoteParam_id
                                                            )),
                                                        Expression.Constant(true, typeof(bool)
                                                        ));

            //* Debug.LogError($"直接调用方法失败: 未找到方法 {path}");
            var localNotFoundError = Expression.Call(
                                        null, typeof(Debug).GetMethod("LogError", new Type[] { typeof(object) }),
                                        Expression.Call(typeof(string).GetMethod("Concat", new Type[] { typeof(string), typeof(string) }),
                                            Expression.Constant("直接调用方法失败: 未找到方法 ", typeof(string)),
                                            localParam_id
                                        ));

            //SubStep 2: 定义方法体 (Switch)
            var remoteBody = Expression.Switch(remoteParam_id, remoteNotFoundError, remoteCases.ToArray());
            var localBody = Expression.Switch(localParam_id, localNotFoundError, localCases.ToArray());

            //SubStep 3: 编译
            Remote = Expression.Lambda<Func<string, NetworkConnection, string[], Entity, bool>>(remoteBody, "Remote_Lambda", new ParameterExpression[] { remoteParam_id, remoteParam_caller, remoteParam_writer, remoteParam_instance }).Compile();
            LocalMethod = Expression.Lambda<Action<string, NetworkConnection, string[], Entity>>(localBody, "LocalMethod_Lambda", new ParameterExpression[] { localParam_id, localParam_caller, localParam_parameters, localParam_instance }).Compile();




            SyncPacker.Init();
        }

        public static void LocalCall(string mtdPath, NetworkConnection caller, string[] parameters, uint instance)
        {
            try
            {
                LocalMethod(mtdPath, caller, parameters, Entity.GetEntityByNetId(instance));
            }
            catch (Exception ex)
            {
                throw new($"\n调用本地方法 {mtdPath} 时发生了异常!!!\n具体异常如下, 其可以是字节转换器的问题, 也可以是被调用的本地方法本身诱发的异常!\n异常将被抛出以防止破坏客户端和服务器!\n{ex}");
            }
        }
    }

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property, Inherited = false)]
    public class NonNetworkAttribute : Attribute
    {

    }
}