using System.Collections.Generic;
using GameCore.Converters;
using Mirror;
using UnityEngine;
using System.Linq;
using System;
using Newtonsoft.Json.Linq;
using SP.Tools;
using Newtonsoft.Json;
using System.IO;

namespace GameCore
{
    public class JsonConvertersClassAttribute : Attribute
    {

    }

    [JsonConvertersClass]
    public static class JsonConverters
    {
        public class NetworkIdentityConverter : JsonConverter<NetworkIdentity>
        {
            public override NetworkIdentity ReadJson(JsonReader reader, Type objectType, NetworkIdentity existingValue, bool hasExistingValue, JsonSerializer serializer)
            {
                if (!NetworkServer.spawned.TryGetValue(ByteConverter.ToUInt(reader.ReadAsBytes()), out NetworkIdentity identity))
                    Debug.LogError($"网络调用失败, netId 未找到");

                return identity;
            }

            public override void WriteJson(JsonWriter writer, NetworkIdentity value, JsonSerializer serializer)
            {
                writer.WriteValue(value.netId);
            }
        }


        public class EntityConverter : JsonConverter<Entity>
        {
            public override Entity ReadJson(JsonReader reader, Type objectType, Entity existingValue, bool hasExistingValue, JsonSerializer serializer)
            {
                var bytes = reader.ReadAsBytes();

                return bytes != null ? Entity.GetEntityByNetId(ByteConverter.ToUInt(bytes)) : null;
            }

            public override void WriteJson(JsonWriter writer, Entity value, JsonSerializer serializer)
            {
                writer.WriteValue(value == null ? uint.MaxValue : value.netId);
            }
        }


        public class CreatureConverter : JsonConverter<Creature>
        {
            public override Creature ReadJson(JsonReader reader, Type objectType, Creature existingValue, bool hasExistingValue, JsonSerializer serializer)
            {
                var bytes = reader.ReadAsBytes();

                return bytes != null ? Entity.GetEntityByNetId<Creature>(ByteConverter.ToUInt(bytes)) : null;
            }

            public override void WriteJson(JsonWriter writer, Creature value, JsonSerializer serializer)
            {
                writer.WriteValue(value == null ? uint.MaxValue : value.netId);
            }
        }


        public class PlayerConverter : JsonConverter<Player>
        {
            public override Player ReadJson(JsonReader reader, Type objectType, Player existingValue, bool hasExistingValue, JsonSerializer serializer)
            {
                var bytes = reader.ReadAsBytes();

                return bytes != null ? Entity.GetEntityByNetId<Player>(ByteConverter.ToUInt(bytes)) : null;
            }

            public override void WriteJson(JsonWriter writer, Player value, JsonSerializer serializer)
            {
                writer.WriteValue(value == null ? uint.MaxValue : value.netId);
            }
        }


        public class EnemyConverter : JsonConverter<Enemy>
        {
            public override Enemy ReadJson(JsonReader reader, Type objectType, Enemy existingValue, bool hasExistingValue, JsonSerializer serializer)
            {
                var bytes = reader.ReadAsBytes();

                return bytes != null ? Entity.GetEntityByNetId<Enemy>(ByteConverter.ToUInt(bytes)) : null;
            }

            public override void WriteJson(JsonWriter writer, Enemy value, JsonSerializer serializer)
            {
                writer.WriteValue(value == null ? uint.MaxValue : value.netId);
            }
        }


        public class DropConverter : JsonConverter<Drop>
        {
            public override Drop ReadJson(JsonReader reader, Type objectType, Drop existingValue, bool hasExistingValue, JsonSerializer serializer)
            {
                var bytes = reader.ReadAsBytes();

                return bytes != null ? Entity.GetEntityByNetId<Drop>(ByteConverter.ToUInt(bytes)) : null;
            }

            public override void WriteJson(JsonWriter writer, Drop value, JsonSerializer serializer)
            {
                writer.WriteValue(value == null ? uint.MaxValue : value.netId);
            }
        }


        public class NPCConverter : JsonConverter<NPC>
        {
            public override NPC ReadJson(JsonReader reader, Type objectType, NPC existingValue, bool hasExistingValue, JsonSerializer serializer)
            {
                var bytes = reader.ReadAsBytes();

                return bytes != null ? Entity.GetEntityByNetId<NPC>(ByteConverter.ToUInt(bytes)) : null;
            }

            public override void WriteJson(JsonWriter writer, NPC value, JsonSerializer serializer)
            {
                writer.WriteValue(value == null ? uint.MaxValue : value.netId);
            }
        }


        public class AudioClipConverter : JsonConverter<AudioClip>
        {
            public override AudioClip ReadJson(JsonReader reader, Type objectType, AudioClip existingValue, bool hasExistingValue, JsonSerializer serializer)
            {
                return ByteConverter.ToAudioClip(reader.ReadAsBytes());
            }

            public override void WriteJson(JsonWriter writer, AudioClip value, JsonSerializer serializer)
            {
                writer.WriteValue(ByteConverter.ToBytes(value));
            }
        }


        public class SpriteConverter : JsonConverter<Sprite>
        {
            public override Sprite ReadJson(JsonReader reader, Type objectType, Sprite existingValue, bool hasExistingValue, JsonSerializer serializer)
            {
                if (reader.Value == null)
                {
                    return null;
                }
                else
                {
                    using var stream = new MemoryStream(Convert.FromBase64String((string)reader.Value));
                    using var binaryReader = new BinaryReader(stream);

                    var pixelsPerUnit = binaryReader.ReadSingle();
                    var textureData = binaryReader.ReadBytes((int)(stream.Length - stream.Position));

                    return ByteConverter.ToSprite(
                        textureData,
                        FilterMode.Point,
                        pixelsPerUnit,
                        TextureFormat.RGBA32
                    );
                }
            }

            public override void WriteJson(JsonWriter writer, Sprite value, JsonSerializer serializer)
            {
                if (!value)
                {
                    writer.WriteNull();
                }
                else
                {
                    using var stream = new MemoryStream();
                    using var binary = new BinaryWriter(stream);

                    binary.Write(value.pixelsPerUnit);
                    binary.Write(ByteConverter.ToBytes(value));
                    binary.Flush();
                    
                    writer.WriteValue(stream.ToArray());
                }
            }
        }


        public class Texture2DConverter : JsonConverter<Texture2D>
        {
            public override Texture2D ReadJson(JsonReader reader, Type objectType, Texture2D existingValue, bool hasExistingValue, JsonSerializer serializer)
            {
                return ByteConverter.ToTexture2D(reader.ReadAsBytes());
            }

            public override void WriteJson(JsonWriter writer, Texture2D value, JsonSerializer serializer)
            {
                writer.WriteValue(ByteConverter.ToBytes(value));
            }
        }
    }
}