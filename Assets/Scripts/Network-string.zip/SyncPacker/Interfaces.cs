namespace GameCore
{
    public interface IVarInstanceID
    {
        uint varInstanceId { get; }
    }
}